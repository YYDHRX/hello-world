

var app = require('express')();
var http=require('http').Server(app);
var io=require('socket.io')(http);
app.get('/', function(req, res){
    res.sendFile(__dirname + '/public/a.html');
  });

http.listen(3000,function () {
    console.log("listen on :3000");
});
io.on('connection',function(socket){
    socket.on ('hear',function(data,fn){
        console.log(data);
        fn("yes,i'm");
    })
    socket.emit('connection','hhhhhhhhhhhhhhhhhhhhhhhhhh233333333333333');
    console.log("a user connected "+socket.id);
});